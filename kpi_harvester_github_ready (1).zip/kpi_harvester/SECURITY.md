# Sicherheit / Responsible Disclosure

Wenn du eine Sicherheitslücke findest, melde sie bitte vertraulich per E-Mail an die in `.env` konfigurierte Alert-Adresse.
Bitte keine öffentlich ausnutzbaren Details in Issues posten.
