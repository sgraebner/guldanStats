
from __future__ import annotations
import requests, datetime as dt, time
from typing import Dict
from tenacity import retry, stop_after_attempt, wait_exponential

ENV_URL = {
    "production": "https://apiz.ebay.com",
    "sandbox": "https://api.sandbox.ebay.com"
}

@retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=8))
def _refresh_access_token(base: str, app_id: str, cert_id: str, redirect_uri: str, refresh_token: str) -> str:
    url = f"{base}/identity/v1/oauth2/token"
    data = {
        "grant_type":"refresh_token",
        "refresh_token": refresh_token,
        "scope": "https://api.ebay.com/oauth/api_scope/sell.fulfillment.readonly"
    }
    r = requests.post(url, data=data, auth=(app_id, cert_id), timeout=30)
    r.raise_for_status()
    return r.json()["access_token"]

def fetch_ebay_daily(account: dict, date: dt.date) -> Dict[str, float]:
    base = ENV_URL.get(account["environment"], ENV_URL["production"])
    access_token = _refresh_access_token(base, account["app_id"], account["cert_id"], account["redirect_uri"], account["refresh_token"])
    # get orders created yesterday, sum total
    start = dt.datetime(date.year, date.month, date.day, 0, 0, 0).isoformat() + "Z"
    end = (dt.datetime(date.year, date.month, date.day) + dt.timedelta(days=1)).isoformat() + "Z"
    url = f"{base}/sell/fulfillment/v1/order"
    params = {
        "filter": f"creationdate:[{start}..{end})"
    }
    headers = {"Authorization": f"Bearer {access_token}", "Content-Type":"application/json", "Accept":"application/json"}
    total = 0.0
    while True:
        r = requests.get(url, headers=headers, params=params, timeout=30)
        r.raise_for_status()
        data = r.json()
        for o in data.get("orders", []):
            t = o.get("pricingSummary", {}).get("total", {})
            if t.get("currency") == "EUR":
                total += float(t.get("value") or 0.0)
        nxt = data.get("href") and data.get("next")
        if not nxt:
            break
        url = nxt
        params = {}
    return { f"ebay_{account['name']}_umsatz_brutto_eur": round(total, 2) }
